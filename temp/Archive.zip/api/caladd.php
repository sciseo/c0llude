<?php
if (isset($_POST['submit'])) {
  CalAdd();
}

function CalAdd() {
$original = file('../whiteboard/calendar/calendar.txt');
?>
