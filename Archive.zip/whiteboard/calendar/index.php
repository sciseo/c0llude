<!doctype html>
<html>

<head>

	<meta charset="utf-8">
	<meta name=viewport content="width=device-width, initial-scale=1">

	<title><?php include '../../settings/site_name.txt';?> | c0llude</title>

        <link rel="stylesheet" href="../../api/css/index.css" type="text/css">
        <link rel="stylesheet" href="../../api/css/fonts.css" type="text/css">

</head>
<body>

<div class="base"></div>
<a href="<?php include '../../settings/site_url.txt';?>" id="logo"></a>

<div id="menu">
	<a href="<?php include '../../settings/site_url.txt';?>" class="nav">Dashboard</a>
	<a href="../" class="nav">Whiteboard</a>
                <a class="sel sub">Calendar</a>
                <a href="../tasks/" class="nav sub">Task List</a>
	<a href="../../inbox/" class="nav">Inbox <?php include '../../api/inbox.php';?></a>
</div>
<div id="prefs">
	<a href="../../settings/">Settings</a>
	<a href="https://neflabs.com/contact/" target="_blank" class="help">Help</a>
</div>

<div class="page light pad"><span class="large">Calendar</span>

	<?php include 'calendar.txt';?>

</div>

</body>
</html>

