<?php
$linecount = 0;
$fh = fopen(__DIR__ . '/../whiteboard/tasks/tasks.txt', 'r');

while (($line = fgets($fh)) !== FALSE) {
  if ($line === "\n") {
    continue;
  }
  $linecount++;
}
$padded = sprintf("%02d", $linecount);
print $padded;
?>
